import React from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import './styles.css';
import Home from './pages/Home';
import QuizList from './features/quiz/QuizList';
import QuizCreate from './features/quiz/QuizCreate';
import StudentRegister from './features/student/StudentRegister';
import AttemptPage from './features/attempt/AttemptPage';
import ReportPage from './features/attempt/ReportPage';

function App(){return <><header><h1>QuizWiz</h1><nav><Link to="/">Home</Link><Link to="/quizzes">Quizzes</Link><Link to="/quiz/create">Create Quiz</Link><Link to="/student/register">Student</Link></nav></header><main><Routes><Route path="/" element={<Home/>}/><Route path="/quizzes" element={<QuizList/>}/><Route path="/quiz/create" element={<QuizCreate/>}/><Route path="/student/register" element={<StudentRegister/>}/><Route path="/attempt/:quizId" element={<AttemptPage/>}/><Route path="/report/:quizId" element={<ReportPage/>}/></Routes></main></>}
createRoot(document.getElementById('root')).render(<BrowserRouter><App/></BrowserRouter>);
