const BASE='http://localhost:8080/api';
async function request(path, options={}){
  const res=await fetch(BASE+path,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});
  if(!res.ok){let data={};try{data=await res.json()}catch{};throw new Error(data.message||`Request failed: ${res.status}`)}
  if(res.status===204)return null; return res.json();
}
export const api={
 quizzes:()=>request('/quizzes'), quiz:id=>request(`/quizzes/${id}`), createQuiz:data=>request('/quizzes',{method:'POST',body:JSON.stringify(data)}),
 students:()=>request('/students'), createStudent:data=>request('/students',{method:'POST',body:JSON.stringify(data)}),
 startAttempt:data=>request('/attempts/start',{method:'POST',body:JSON.stringify(data)}),
 saveAnswer:(attemptId,questionId,selectedOption)=>request(`/attempts/${attemptId}/answers/${questionId}?selectedOption=${selectedOption}`,{method:'PUT'}),
 submit:(id,answers)=>request(`/attempts/${id}/submit`,{method:'POST',body:JSON.stringify({answers})}),
 report:quizId=>request(`/attempts/report/${quizId}`)
};
