# QuizWiz — Spring Boot + React Vertical Slice Project

## Project structure

```text
quizwiz/
├── backend/                         # IntelliJ / Spring Boot
│   └── src/main/java/com/quizwiz/
│       ├── common/                  # shared API errors
│       ├── quiz/                    # Quiz vertical slice
│       │   ├── Quiz.java
│       │   ├── QuizRepository.java
│       │   ├── QuizService.java
│       │   ├── QuizController.java
│       │   └── QuizDtos.java
│       ├── question/                # Question vertical slice
│       ├── student/                 # Student vertical slice
│       └── attempt/                 # Attempt + AttemptAnswer vertical slice
└── frontend/                        # React/Vite
    └── src/
        ├── api/
        ├── features/quiz/
        ├── features/question/
        ├── features/student/
        └── features/attempt/
```

## IntelliJ setup

1. Open the `backend` folder in IntelliJ IDEA as a Maven project.
2. Use JDK 21.
3. Create MySQL database/user, then edit `backend/src/main/resources/application.properties`:

```properties
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

4. Run `QuizWizApplication.java`.
5. Backend runs at `http://localhost:8080`.

## Frontend setup

From the `frontend` folder:

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally `http://localhost:5173`.

## Main API endpoints

### Quiz slice
- `POST /api/quizzes` — faculty creates a quiz and its MCQs
- `GET /api/quizzes` — list quizzes
- `GET /api/quizzes/{id}` — student-safe quiz data; correct answers are not returned

### Student slice
- `POST /api/students` — register student
- `GET /api/students` — list students
- `GET /api/students/{id}` — get student

### Attempt slice
- `POST /api/attempts/start` — start a quiz
- `PUT /api/attempts/{attemptId}/answers/{questionId}?selectedOption=A` — save an answer
- `POST /api/attempts/{attemptId}/submit` — submit
- `GET /api/attempts/report/{quizId}` — class-wise report

## Business rules implemented

1. A student can attempt a quiz only once. Database unique constraint: `(student_id, quiz_id)`.
2. Attempt expiry is calculated on the server.
3. Answers are saved while the quiz is running, allowing server-side auto-submit.
4. A scheduled job checks expired attempts every 5 seconds and submits them.
5. Answers submitted after expiry are rejected/ignored by the service.
6. Score is based only on questions actually answered: `correct / answered * 100`.
7. Invalid requests return clear JSON error messages through `@RestControllerAdvice`.
8. Correct answers are never exposed by the student quiz GET endpoint.
