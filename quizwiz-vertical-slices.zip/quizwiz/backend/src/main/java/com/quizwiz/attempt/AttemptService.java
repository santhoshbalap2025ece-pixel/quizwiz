package com.quizwiz.attempt;

import com.quizwiz.common.ApiException;
import com.quizwiz.question.Question;
import com.quizwiz.question.QuestionRepository;
import com.quizwiz.quiz.Quiz;
import com.quizwiz.quiz.QuizRepository;
import com.quizwiz.student.Student;
import com.quizwiz.student.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class AttemptService {
 private final AttemptRepository attempts; private final StudentRepository students; private final QuizRepository quizzes; private final QuestionRepository questions;
 public AttemptService(AttemptRepository a,StudentRepository s,QuizRepository q,QuestionRepository qr){attempts=a;students=s;quizzes=q;questions=qr;}

 @Transactional
 public AttemptDtos.StartResponse start(AttemptDtos.StartRequest r){
  if(attempts.existsByStudentIdAndQuizId(r.studentId(),r.quizId())) throw new ApiException(HttpStatus.CONFLICT,"Student has already attempted this quiz");
  Student student=students.findById(r.studentId()).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Student not found"));
  Quiz quiz=quizzes.findById(r.quizId()).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Quiz not found"));
  LocalDateTime started=LocalDateTime.now(), expires=started.plusMinutes(quiz.getTimeLimitMinutes());
  Attempt a=new Attempt();a.setStudent(student);a.setQuiz(quiz);a.setStartedAt(started);a.setExpiresAt(expires);a.setStatus(AttemptStatus.IN_PROGRESS);a.setAnsweredCount(0);a.setCorrectCount(0);a.setScore(0);
  a=attempts.save(a); return new AttemptDtos.StartResponse(a.getId(),quiz.getId(),quiz.getTitle(),started,expires);
 }

 @Transactional
 public AttemptDtos.ResultResponse submit(Long id,AttemptDtos.SubmitRequest request){
  Attempt a=attempts.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Attempt not found"));
  if(a.getStatus()==AttemptStatus.SUBMITTED) throw new ApiException(HttpStatus.CONFLICT,"Attempt is already submitted");
  boolean expired=LocalDateTime.now().isAfter(a.getExpiresAt());
  if (expired) { calculate(a); a.setStatus(AttemptStatus.SUBMITTED); a.setSubmittedAt(LocalDateTime.now()); attempts.save(a); return result(a,true); }
  List<AttemptDtos.AnswerInput> submittedAnswers = request.answers() == null ? List.of() : request.answers();
  Map<Long,String> unique=new HashMap<>();
  for(AttemptDtos.AnswerInput input:submittedAnswers){
   if(unique.put(input.questionId(),input.selectedOption())!=null) throw new ApiException(HttpStatus.BAD_REQUEST,"A question cannot be answered twice");
   Question q=questions.findById(input.questionId()).orElseThrow(()->new ApiException(HttpStatus.BAD_REQUEST,"Question not found: "+input.questionId()));
   if(!q.getQuiz().getId().equals(a.getQuiz().getId())) throw new ApiException(HttpStatus.BAD_REQUEST,"Question does not belong to this quiz");
  }
  for(var e:unique.entrySet()){
   Question q=questions.findById(e.getKey()).orElseThrow();
   AttemptAnswer aa=a.getAnswers().stream().filter(x->x.getQuestion().getId().equals(q.getId())).findFirst().orElse(null);
   if(aa==null){ aa=new AttemptAnswer(); aa.setAttempt(a); aa.setQuestion(q); a.getAnswers().add(aa); }
   aa.setSelectedOption(e.getValue());
  }
  calculate(a); a.setStatus(AttemptStatus.SUBMITTED);a.setSubmittedAt(LocalDateTime.now());attempts.save(a);
  return result(a,expired);
 }

 @Transactional
 public void saveAnswer(Long attemptId, Long questionId, String selectedOption){
  Attempt a=attempts.findById(attemptId).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Attempt not found"));
  if(a.getStatus()==AttemptStatus.SUBMITTED) throw new ApiException(HttpStatus.CONFLICT,"Attempt is already submitted");
  if(LocalDateTime.now().isAfter(a.getExpiresAt())) throw new ApiException(HttpStatus.CONFLICT,"Time limit has expired; the attempt is being auto-submitted");
  Question q=questions.findById(questionId).orElseThrow(()->new ApiException(HttpStatus.BAD_REQUEST,"Question not found"));
  if(!q.getQuiz().getId().equals(a.getQuiz().getId())) throw new ApiException(HttpStatus.BAD_REQUEST,"Question does not belong to this quiz");
  AttemptAnswer existing=a.getAnswers().stream().filter(x->x.getQuestion().getId().equals(questionId)).findFirst().orElse(null);
  if(existing==null){ existing=new AttemptAnswer(); existing.setAttempt(a); existing.setQuestion(q); a.getAnswers().add(existing); }
  existing.setSelectedOption(selectedOption); attempts.save(a);
 }

 private void calculate(Attempt a){
  int answered=a.getAnswers().size(),correct=0; for(AttemptAnswer x:a.getAnswers()) if(x.getSelectedOption().equalsIgnoreCase(x.getQuestion().getCorrectOption())) correct++;
  a.setAnsweredCount(answered);a.setCorrectCount(correct);a.setScore(answered==0?0:(int)Math.round(correct*100.0/answered));
 }
 private AttemptDtos.ResultResponse result(Attempt a,boolean auto){return new AttemptDtos.ResultResponse(a.getId(),a.getStatus().name(),auto,a.getAnsweredCount(),a.getCorrectCount(),a.getScore(),a.getSubmittedAt());}

 @Transactional
 @Scheduled(fixedDelay=5000)
 public void autoSubmitExpired(){
  for(Attempt a:attempts.findByStatusAndExpiresAtBefore(AttemptStatus.IN_PROGRESS,LocalDateTime.now())){
   calculate(a);a.setStatus(AttemptStatus.SUBMITTED);a.setSubmittedAt(LocalDateTime.now());attempts.save(a);
  }
 }

 @Transactional(readOnly=true)
 public List<AttemptDtos.ReportRow> report(Long quizId){
  if(!quizzes.existsById(quizId)) throw new ApiException(HttpStatus.NOT_FOUND,"Quiz not found");
  return attempts.findByQuizIdAndStatus(quizId,AttemptStatus.SUBMITTED).stream().map(a->new AttemptDtos.ReportRow(a.getStudent().getId(),a.getStudent().getName(),a.getId(),a.getAnsweredCount(),a.getCorrectCount(),a.getScore(),a.getStatus().name())).toList();
 }
}
