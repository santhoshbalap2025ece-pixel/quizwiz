package com.quizwiz.quiz;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.List;

public final class QuizDtos {
    private QuizDtos() {}
    public record QuestionInput(@NotBlank String text, @NotBlank String optionA, @NotBlank String optionB, @NotBlank String optionC, @NotBlank String optionD, @NotBlank @Pattern(regexp="[ABCD]") String correctOption) {}
    public record CreateQuizRequest(@NotBlank String title, String description, @NotNull @Positive Integer timeLimitMinutes, @NotEmpty List<@Valid QuestionInput> questions) {}
    public record QuestionView(Long id, String text, String optionA, String optionB, String optionC, String optionD) {}
    public record QuizView(Long id, String title, String description, Integer timeLimitMinutes, List<QuestionView> questions) {}
}
