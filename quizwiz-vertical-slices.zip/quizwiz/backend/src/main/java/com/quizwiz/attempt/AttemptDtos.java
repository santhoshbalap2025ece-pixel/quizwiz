package com.quizwiz.attempt;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import java.util.List;
public final class AttemptDtos { private AttemptDtos(){}
 public record StartRequest(@NotNull Long studentId,@NotNull Long quizId){}
 public record AnswerInput(@NotNull Long questionId,@NotBlank @Pattern(regexp="[ABCD]") String selectedOption){}
 public record SubmitRequest(List<AnswerInput> answers){}
 public record StartResponse(Long attemptId,Long quizId,String quizTitle,LocalDateTime startedAt,LocalDateTime expiresAt){}
 public record ResultResponse(Long attemptId,String status,boolean autoSubmitted,Integer answeredCount,Integer correctCount,Integer score,LocalDateTime submittedAt){}
 public record ReportRow(Long studentId,String studentName,Long attemptId,Integer answeredCount,Integer correctCount,Integer score,String status){}
}
