package com.quizwiz.student;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/students") @CrossOrigin(origins="http://localhost:5173")
public class StudentController {
 private final StudentService service; public StudentController(StudentService service){this.service=service;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public StudentDtos.StudentView create(@Valid @RequestBody StudentDtos.CreateStudentRequest r){return view(service.create(r));}
 @GetMapping public List<StudentDtos.StudentView> all(){return service.all().stream().map(this::view).toList();}
 @GetMapping("/{id}") public StudentDtos.StudentView get(@PathVariable Long id){return view(service.get(id));}
 private StudentDtos.StudentView view(Student s){return new StudentDtos.StudentView(s.getId(),s.getName(),s.getEmail());}
}
