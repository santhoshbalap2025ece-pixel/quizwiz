package com.quizwiz.question;
import com.quizwiz.common.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
@Service public class QuestionService {
    private final QuestionRepository repo;
    public QuestionService(QuestionRepository repo){this.repo=repo;}
    public Question get(Long id){return repo.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Question not found"));}
}
