package com.quizwiz.attempt;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.*;
public interface AttemptRepository extends JpaRepository<Attempt,Long>{
 boolean existsByStudentIdAndQuizId(Long studentId,Long quizId);
 List<Attempt> findByStatusAndExpiresAtBefore(AttemptStatus status, LocalDateTime time);
 Optional<Attempt> findByIdAndStudentId(Long id,Long studentId);
 List<Attempt> findByQuizIdAndStatus(Long quizId,AttemptStatus status);
}
