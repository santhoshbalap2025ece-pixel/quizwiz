package com.quizwiz.quiz;

import com.quizwiz.common.ApiException;
import com.quizwiz.question.Question;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class QuizService {
    private final QuizRepository repo;
    public QuizService(QuizRepository repo) { this.repo = repo; }

    @Transactional
    public Quiz create(QuizDtos.CreateQuizRequest req) {
        Quiz quiz = new Quiz(); quiz.setTitle(req.title()); quiz.setDescription(req.description()); quiz.setTimeLimitMinutes(req.timeLimitMinutes());
        for (QuizDtos.QuestionInput q : req.questions()) {
            Question question = new Question(); question.setText(q.text()); question.setOptionA(q.optionA()); question.setOptionB(q.optionB()); question.setOptionC(q.optionC()); question.setOptionD(q.optionD()); question.setCorrectOption(q.correctOption()); question.setQuiz(quiz); quiz.getQuestions().add(question);
        }
        return repo.save(quiz);
    }
    public List<Quiz> all() { return repo.findAll(); }
    public Quiz get(Long id) { return repo.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND,"Quiz not found")); }
}
