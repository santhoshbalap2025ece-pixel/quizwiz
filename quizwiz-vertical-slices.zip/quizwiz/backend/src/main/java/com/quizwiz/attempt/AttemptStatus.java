package com.quizwiz.attempt;
public enum AttemptStatus { IN_PROGRESS, SUBMITTED }
