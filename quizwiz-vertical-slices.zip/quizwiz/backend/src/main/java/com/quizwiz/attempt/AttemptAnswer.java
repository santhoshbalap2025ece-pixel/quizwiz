package com.quizwiz.attempt;
import com.quizwiz.question.Question;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="attempt_answers", uniqueConstraints=@UniqueConstraint(name="uk_attempt_question",columnNames={"attempt_id","question_id"}))
@Getter @Setter @NoArgsConstructor
public class AttemptAnswer {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) private Attempt attempt;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) private Question question;
 @Column(nullable=false,length=1) private String selectedOption;
}
