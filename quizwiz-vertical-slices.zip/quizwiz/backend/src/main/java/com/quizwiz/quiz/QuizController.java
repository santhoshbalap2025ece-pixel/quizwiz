package com.quizwiz.quiz;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController @RequestMapping("/api/quizzes") @CrossOrigin(origins="http://localhost:5173")
public class QuizController {
    private final QuizService service;
    public QuizController(QuizService service) { this.service = service; }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public QuizDtos.QuizView create(@Valid @RequestBody QuizDtos.CreateQuizRequest request) { return view(service.create(request)); }
    @GetMapping public List<QuizDtos.QuizView> all() { return service.all().stream().map(this::view).toList(); }
    @GetMapping("/{id}") public QuizDtos.QuizView get(@PathVariable Long id) { return view(service.get(id)); }
    private QuizDtos.QuizView view(Quiz q) {
        return new QuizDtos.QuizView(q.getId(),q.getTitle(),q.getDescription(),q.getTimeLimitMinutes(),q.getQuestions().stream().map(x -> new QuizDtos.QuestionView(x.getId(),x.getText(),x.getOptionA(),x.getOptionB(),x.getOptionC(),x.getOptionD())).collect(Collectors.toList()));
    }
}
