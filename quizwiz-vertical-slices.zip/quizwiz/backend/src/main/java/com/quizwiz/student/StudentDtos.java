package com.quizwiz.student;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
public final class StudentDtos { private StudentDtos(){}
 public record CreateStudentRequest(@NotBlank String name,@NotBlank @Email String email){}
 public record StudentView(Long id,String name,String email){}
}
