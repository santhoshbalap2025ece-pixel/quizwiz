package com.quizwiz.attempt;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/attempts") @CrossOrigin(origins="http://localhost:5173")
public class AttemptController {
 private final AttemptService service; public AttemptController(AttemptService service){this.service=service;}
 @PostMapping("/start") @ResponseStatus(HttpStatus.CREATED) public AttemptDtos.StartResponse start(@Valid @RequestBody AttemptDtos.StartRequest r){return service.start(r);}
 @PutMapping("/{id}/answers/{questionId}") @ResponseStatus(HttpStatus.NO_CONTENT) public void saveAnswer(@PathVariable Long id,@PathVariable Long questionId,@RequestParam String selectedOption){service.saveAnswer(id,questionId,selectedOption);}
 @PostMapping("/{id}/submit") public AttemptDtos.ResultResponse submit(@PathVariable Long id,@Valid @RequestBody AttemptDtos.SubmitRequest r){return service.submit(id,r);}
 @GetMapping("/report/{quizId}") public List<AttemptDtos.ReportRow> report(@PathVariable Long quizId){return service.report(quizId);}
}
