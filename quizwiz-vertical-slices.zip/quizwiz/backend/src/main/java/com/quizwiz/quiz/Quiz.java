package com.quizwiz.quiz;

import com.quizwiz.question.Question;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name="quizzes") @Getter @Setter @NoArgsConstructor
public class Quiz {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @NotBlank private String title;
    private String description;
    @Positive private Integer timeLimitMinutes;
    @OneToMany(mappedBy="quiz", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<Question> questions = new ArrayList<>();
}
