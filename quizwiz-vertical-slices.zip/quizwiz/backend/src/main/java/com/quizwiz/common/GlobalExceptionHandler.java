package com.quizwiz.common;

import jakarta.validation.ConstraintViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ApiException.class)
    public ResponseEntity<?> api(ApiException ex) { return ResponseEntity.status(ex.getStatus()).body(body(ex.getMessage())); }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> validation(MethodArgumentNotValidException ex) {
        String msg = ex.getBindingResult().getFieldErrors().stream().map(e -> e.getField()+": "+e.getDefaultMessage()).findFirst().orElse("Invalid request");
        return ResponseEntity.badRequest().body(body(msg));
    }
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<?> constraint(ConstraintViolationException ex) { return ResponseEntity.badRequest().body(body(ex.getMessage())); }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> generic(Exception ex) { return ResponseEntity.internalServerError().body(body("Unexpected server error")); }
    private Map<String,Object> body(String message) {
        Map<String,Object> m = new LinkedHashMap<>(); m.put("timestamp", LocalDateTime.now()); m.put("message", message); return m;
    }
}
