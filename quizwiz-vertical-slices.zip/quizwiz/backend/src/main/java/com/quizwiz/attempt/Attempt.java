package com.quizwiz.attempt;
import com.quizwiz.quiz.Quiz;
import com.quizwiz.student.Student;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name="attempts", uniqueConstraints=@UniqueConstraint(name="uk_student_quiz", columnNames={"student_id","quiz_id"}))
@Getter @Setter @NoArgsConstructor
public class Attempt {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) private Student student;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) private Quiz quiz;
 private LocalDateTime startedAt;
 private LocalDateTime expiresAt;
 private LocalDateTime submittedAt;
 private Integer score;
 private Integer answeredCount;
 private Integer correctCount;
 @Enumerated(EnumType.STRING) private AttemptStatus status;
 @OneToMany(mappedBy="attempt",cascade=CascadeType.ALL,orphanRemoval=true) private List<AttemptAnswer> answers=new ArrayList<>();
}
