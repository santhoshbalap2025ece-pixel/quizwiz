package com.quizwiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class QuizWizApplication {
    public static void main(String[] args) {
        SpringApplication.run(QuizWizApplication.class, args);
    }
}
