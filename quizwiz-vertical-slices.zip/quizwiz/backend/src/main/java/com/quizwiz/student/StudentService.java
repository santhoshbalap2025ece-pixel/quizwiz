package com.quizwiz.student;
import com.quizwiz.common.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.List;
@Service public class StudentService {
 private final StudentRepository repo;
 public StudentService(StudentRepository repo){this.repo=repo;}
 public Student create(StudentDtos.CreateStudentRequest r){ if(repo.findByEmail(r.email()).isPresent()) throw new ApiException(HttpStatus.CONFLICT,"Email already registered"); Student s=new Student();s.setName(r.name());s.setEmail(r.email());return repo.save(s); }
 public List<Student> all(){return repo.findAll();}
 public Student get(Long id){return repo.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Student not found"));}
}
