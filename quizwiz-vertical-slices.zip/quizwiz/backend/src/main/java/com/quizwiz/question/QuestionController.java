package com.quizwiz.question;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/questions") @CrossOrigin(origins="http://localhost:5173")
public class QuestionController {
    private final QuestionService service; public QuestionController(QuestionService service){this.service=service;}
    @GetMapping("/{id}") public Question get(@PathVariable Long id){return service.get(id);}
}
